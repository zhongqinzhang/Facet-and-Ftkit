# Third-party build and runtime dependencies

This private preview includes the following Cargo dependency notices.
Some packages are build-time dependencies. Their inclusion here does not
mean that they are all linked into the executable.

| Package | Version | Declared license | License texts |
| --- | --- | --- | --- |
| adler2 | 2.0.1 | 0BSD OR MIT OR Apache-2.0 | [files](licenses/adler2-2.0.1/) |
| approx | 0.5.1 | Apache-2.0 | [files](licenses/approx-0.5.1/) |
| autocfg | 1.5.1 | Apache-2.0 OR MIT | [files](licenses/autocfg-1.5.1/) |
| bitflags | 2.13.1 | MIT OR Apache-2.0 | [files](licenses/bitflags-2.13.1/) |
| block-buffer | 0.10.4 | MIT OR Apache-2.0 | [files](licenses/block-buffer-0.10.4/) |
| bytemuck | 1.25.0 | Zlib OR Apache-2.0 OR MIT | [files](licenses/bytemuck-1.25.0/) |
| cfg-if | 1.0.5 | MIT OR Apache-2.0 | [files](licenses/cfg-if-1.0.5/) |
| cfg_aliases | 0.2.2 | MIT | [files](licenses/cfg_aliases-0.2.2/) |
| chrono | 0.4.45 | MIT OR Apache-2.0 | [files](licenses/chrono-0.4.45/) |
| cpufeatures | 0.2.17 | MIT OR Apache-2.0 | [files](licenses/cpufeatures-0.2.17/) |
| crc32fast | 1.5.2 | MIT OR Apache-2.0 | [files](licenses/crc32fast-1.5.2/) |
| crypto-common | 0.1.7 | MIT OR Apache-2.0 | [files](licenses/crypto-common-0.1.7/) |
| ctrlc | 3.5.2 | MIT/Apache-2.0 | [files](licenses/ctrlc-3.5.2/) |
| digest | 0.10.7 | MIT OR Apache-2.0 | [files](licenses/digest-0.10.7/) |
| displaydoc | 0.2.7 | MIT OR Apache-2.0 | [files](licenses/displaydoc-0.2.7/) |
| dyn-clone | 1.0.20 | MIT OR Apache-2.0 | [files](licenses/dyn-clone-1.0.20/) |
| either | 1.16.0 | MIT OR Apache-2.0 | [files](licenses/either-1.16.0/) |
| equivalent | 1.0.2 | Apache-2.0 OR MIT | [files](licenses/equivalent-1.0.2/) |
| errno | 0.3.14 | MIT OR Apache-2.0 | [files](licenses/errno-0.3.14/) |
| fastrand | 2.5.0 | Apache-2.0 OR MIT | [files](licenses/fastrand-2.5.0/) |
| flate2 | 1.1.10 | MIT OR Apache-2.0 | [files](licenses/flate2-1.1.10/) |
| generic-array | 0.14.7 | MIT | [files](licenses/generic-array-0.14.7/) |
| glam | 0.30.10 | MIT OR Apache-2.0 | [files](licenses/glam-0.30.10/) |
| glam | 0.31.1 | MIT OR Apache-2.0 | [files](licenses/glam-0.31.1/) |
| glam | 0.32.1 | MIT OR Apache-2.0 | [files](licenses/glam-0.32.1/) |
| glam | 0.33.2 | MIT OR Apache-2.0 | [files](licenses/glam-0.33.2/) |
| hashbrown | 0.17.1 | MIT OR Apache-2.0 | [files](licenses/hashbrown-0.17.1/) |
| heck | 0.5.0 | MIT OR Apache-2.0 | [files](licenses/heck-0.5.0/) |
| indexmap | 2.14.2 | Apache-2.0 OR MIT | [files](licenses/indexmap-2.14.2/) |
| itertools | 0.15.0 | MIT OR Apache-2.0 | [files](licenses/itertools-0.15.0/) |
| itoa | 1.0.18 | MIT OR Apache-2.0 | [files](licenses/itoa-1.0.18/) |
| libc | 0.2.189 | MIT OR Apache-2.0 | [files](licenses/libc-0.2.189/) |
| linux-raw-sys | 0.12.1 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [files](licenses/linux-raw-sys-0.12.1/) |
| log | 0.4.33 | MIT OR Apache-2.0 | [files](licenses/log-0.4.33/) |
| matrixmultiply | 0.3.10 | MIT/Apache-2.0 | [files](licenses/matrixmultiply-0.3.10/) |
| memchr | 2.8.3 | Unlicense OR MIT | [files](licenses/memchr-2.8.3/) |
| miniz_oxide | 0.9.1 | MIT OR Zlib OR Apache-2.0 | [files](licenses/miniz_oxide-0.9.1/) |
| moyo | 0.14.0 | MIT OR Apache-2.0 | [files](licenses/moyo-0.14.0/) |
| nalgebra | 0.35.0 | Apache-2.0 | [files](licenses/nalgebra-0.35.0/) |
| nalgebra-macros | 0.3.0 | Apache-2.0 | [files](licenses/nalgebra-macros-0.3.0/) |
| nix | 0.31.3 | MIT | [files](licenses/nix-0.31.3/) |
| num-bigint | 0.4.8 | MIT OR Apache-2.0 | [files](licenses/num-bigint-0.4.8/) |
| num-complex | 0.4.6 | MIT OR Apache-2.0 | [files](licenses/num-complex-0.4.6/) |
| num-integer | 0.1.46 | MIT OR Apache-2.0 | [files](licenses/num-integer-0.1.46/) |
| num-rational | 0.4.2 | MIT OR Apache-2.0 | [files](licenses/num-rational-0.4.2/) |
| num-traits | 0.2.19 | MIT OR Apache-2.0 | [files](licenses/num-traits-0.2.19/) |
| once_cell | 1.21.4 | MIT OR Apache-2.0 | [files](licenses/once_cell-1.21.4/) |
| proc-macro2 | 1.0.107 | MIT OR Apache-2.0 | [files](licenses/proc-macro2-1.0.107/) |
| quote | 1.0.47 | MIT OR Apache-2.0 | [files](licenses/quote-1.0.47/) |
| rawpointer | 0.2.1 | MIT/Apache-2.0 | [files](licenses/rawpointer-0.2.1/) |
| rustc-hash | 2.1.3 | Apache-2.0 OR MIT | [files](licenses/rustc-hash-2.1.3/) |
| rustix | 1.1.4 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [files](licenses/rustix-1.1.4/) |
| safe_arch | 1.0.0 | Zlib OR Apache-2.0 OR MIT | [files](licenses/safe_arch-1.0.0/) |
| same-file | 1.0.6 | Unlicense/MIT | [files](licenses/same-file-1.0.6/) |
| schemars | 0.8.22 | MIT | [files](licenses/schemars-0.8.22/) |
| schemars_derive | 0.8.22 | MIT | [files](licenses/schemars_derive-0.8.22/) |
| serde | 1.0.229 | MIT OR Apache-2.0 | [files](licenses/serde-1.0.229/) |
| serde_core | 1.0.229 | MIT OR Apache-2.0 | [files](licenses/serde_core-1.0.229/) |
| serde_derive | 1.0.229 | MIT OR Apache-2.0 | [files](licenses/serde_derive-1.0.229/) |
| serde_derive_internals | 0.29.1 | MIT OR Apache-2.0 | [files](licenses/serde_derive_internals-0.29.1/) |
| serde_json | 1.0.151 | MIT OR Apache-2.0 | [files](licenses/serde_json-1.0.151/) |
| sha2 | 0.10.9 | MIT OR Apache-2.0 | [files](licenses/sha2-0.10.9/) |
| simba | 0.10.0 | Apache-2.0 | [files](licenses/simba-0.10.0/) |
| simd-adler32 | 0.3.10 | MIT | [files](licenses/simd-adler32-0.3.10/) |
| strum | 0.28.0 | MIT | [files](licenses/strum-0.28.0/) |
| strum_macros | 0.28.0 | MIT | [files](licenses/strum_macros-0.28.0/) |
| syn | 2.0.119 | MIT OR Apache-2.0 | [files](licenses/syn-2.0.119/) |
| syn | 3.0.6 | MIT OR Apache-2.0 | [files](licenses/syn-3.0.6/) |
| tempfile | 3.27.0 | MIT OR Apache-2.0 | [files](licenses/tempfile-3.27.0/) |
| termcolor | 1.4.1 | Unlicense OR MIT | [files](licenses/termcolor-1.4.1/) |
| thiserror | 2.0.21 | MIT OR Apache-2.0 | [files](licenses/thiserror-2.0.21/) |
| thiserror-impl | 2.0.21 | MIT OR Apache-2.0 | [files](licenses/thiserror-impl-2.0.21/) |
| ts-rs | 11.1.0 | MIT | [files](licenses/ts-rs-11.1.0/) |
| ts-rs-macros | 11.1.0 | MIT | [files](licenses/ts-rs-macros-11.1.0/) |
| typenum | 1.20.1 | MIT OR Apache-2.0 | [files](licenses/typenum-1.20.1/) |
| unicode-ident | 1.0.26 | (MIT OR Apache-2.0) AND Unicode-3.0 | [files](licenses/unicode-ident-1.0.26/) |
| union-find | 0.4.4 | MIT OR Apache-2.0 | [files](licenses/union-find-0.4.4/) |
| version_check | 0.9.5 | MIT/Apache-2.0 | [files](licenses/version_check-0.9.5/) |
| wide | 1.5.0 | Zlib OR Apache-2.0 OR MIT | [files](licenses/wide-1.5.0/) |
| zip | 2.4.2 | MIT | [files](licenses/zip-2.4.2/) |
| zmij | 1.0.23 | MIT | [files](licenses/zmij-1.0.23/) |

Rust standard library, musl and bundled runtime notices:
[Rust library copyright file](licenses/Rust-standard-library-COPYRIGHT.html).

ftkit and the local Facet data crates remain the project's own code.
This notice does not assign them a new license.
