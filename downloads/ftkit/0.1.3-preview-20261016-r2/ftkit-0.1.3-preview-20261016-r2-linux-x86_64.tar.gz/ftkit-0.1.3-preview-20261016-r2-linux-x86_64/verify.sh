#!/usr/bin/env bash
# Offline conversion checks; only install the package directory after all checks pass.
set -euo pipefail
export LC_ALL=C
umask 077
install=1
case "$#" in
  0) ;;
  1) test "$1" = --no-install || { printf 'Usage: bash verify.sh [--no-install]\n' >&2; exit 2; }; install=0;;
  *) printf 'Usage: bash verify.sh [--no-install]\n' >&2; exit 2;;
esac
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$package_dir"
results="$(mktemp -d "$package_dir/verification-XXXXXXXX")"
report="$results/report.txt"
exec > >(tee "$report") 2>&1
finish() {
  code=$?
  trap - EXIT
  if [ "$code" -eq 0 ]; then
    printf '\nRESULT: PASS (automatic checks; real TTY and Facet viewer checks remain manual)\n'
  else
    printf '\nRESULT: FAIL (exit %s; PATH installation was not completed)\n' "$code"
  fi
  printf 'Report: %s\nResults: %s\n' "$report" "$results"
  exit "$code"
}
trap finish EXIT
printf 'ftkit magnetic/QE preview verification\n'
date -u
uname -a
if [ -r /etc/os-release ]; then cat /etc/os-release; fi
if [ -r /etc/redhat-release ]; then cat /etc/redhat-release; fi
getconf GNU_LIBC_VERSION || true
if command -v file >/dev/null 2>&1; then file "$package_dir/ftkit"; fi
printf '\n[1] Package checksums\n'
if ! sha256sum -c SHA256SUMS > "$results/checksums.log" 2>&1; then cat "$results/checksums.log"; exit 1; fi
printf 'Checksums: PASS\n'
printf '\n[2] Startup/help\n'
"$package_dir/ftkit" --version
"$package_dir/ftkit" --help > "$results/help.txt"
"$package_dir/ftkit" -help > "$results/help-alias.txt"
cmp "$results/help.txt" "$results/help-alias.txt"
grep -Eq '^[[:space:]]+302[[:space:]]' "$results/help.txt"
if grep -Eq '^[[:space:]]+102[[:space:]]' "$results/help.txt"; then exit 1; fi

printf '\n[3] VASP and QE phonons: parameter, echo, grouped and redirected input\n'
for task in 301 302; do
  for method in flags echo grouped redirected; do
    work="$results/$task-$method"; mkdir "$work"
    if [ "$task" -eq 301 ]; then cp "$package_dir/example/OUTCAR" "$work/OUTCAR"
    else cp "$package_dir"/example/qe/{scf.in,scf.out,matdyn.modes} "$work/"; fi
    (
      cd "$work"
      case "$method" in
        flags) "$package_dir/ftkit" -task "$task";;
        echo) echo "$task" | "$package_dir/ftkit";;
        grouped) (echo "$task"; echo) | "$package_dir/ftkit";;
        redirected) printf '%s\n' "$task" > cmd.in; "$package_dir/ftkit" < cmd.in;;
      esac
    ) > "$work/stdout.log" 2> "$work/stderr.log" || { cat "$work/stderr.log"; exit 1; }
    test -s "$work/phonons.facet"
    if [ "$task" -eq 301 ]; then
      grep -Eq 'Atoms[[:space:]]+80[[:space:]]' "$work/stdout.log"
      grep -Eq 'Modes[[:space:]]+240 per q point' "$work/stdout.log"
      grep -Eq 'Imaginary[[:space:]]+3 across' "$work/stdout.log"
    else
      grep -Eq 'Q-points[[:space:]]+121[[:space:]]' "$work/stdout.log"
      grep -Eq 'Modes[[:space:]]+9 per q point' "$work/stdout.log"
    fi
    if command -v unzip >/dev/null 2>&1; then unzip -t "$work/phonons.facet" > "$work/archive-check.log"; fi
    printf '%s %s: PASS\n' "$task" "$method"
  done
done
printf '\n[4] Collinear, SOC and batch magnetism\n'
for kind in magnetic soc; do
  "$package_dir/ftkit" -task 201 -i "example/$kind/OUTCAR" -o "$results/$kind.facet" \
    > "$results/$kind.log" 2>&1 || { cat "$results/$kind.log"; exit 1; }
  grep -q 'static magnetic structure' "$results/$kind.log"
done
mkdir "$results/batch" "$results/batch/2-AB" "$results/batch/3-FM"
cp example/magnetic/OUTCAR "$results/batch/2-AB/OUTCAR"
cp example/soc/OUTCAR "$results/batch/3-FM/OUTCAR"
(
  cd "$results"
  "$package_dir/ftkit" -task 202 --root batch
) > "$results/batch.log" 2>&1 || { cat "$results/batch.log"; exit 1; }
test -s "$results/magnetic-batch.facetproj"
grep -Eq 'Structures[[:space:]]+2[[:space:]]' "$results/batch.log"
mkdir "$results/batch/missing"
status=0
"$package_dir/ftkit" -task 202 --root "$results/batch" -o "$results/partial.facetproj" \
  > "$results/partial.log" 2>&1 || status=$?
test "$status" -eq 3 && test -s "$results/partial.facetproj"
grep -Eq 'Skipped[[:space:]]+1[[:space:]]' "$results/partial.log"
printf '201 collinear/SOC; 202 complete/partial: PASS\n'
printf '\n[5] Replace results silently and preserve input files\n'
output="$results/301-flags/phonons.facet"
printf 'previous generated result\n' > "$output"
"$package_dir/ftkit" -task 301 -i example/OUTCAR -o "$output" > "$results/replace-output.log" 2>&1
test -s "$output"
grep -Eq 'Type[[:space:]]+phonon[[:space:]]' "$results/replace-output.log"
if command -v unzip >/dev/null 2>&1; then unzip -t "$output" > "$results/replaced-archive-check.log"; fi
source="$results/input-protection-OUTCAR"
cp example/magnetic/OUTCAR "$source"
before="$(sha256sum "$source")"; status=0
"$package_dir/ftkit" -task 201 -i "$source" -o "$source" > "$results/protect-input.log" 2>&1 || status=$?
test "$status" -eq 2 && test "$before" = "$(sha256sum "$source")"
printf 'Automatic output replacement; input protection: PASS\n'
printf '\nManual viewer files: magnetic.facet, soc.facet, magnetic-batch.facetproj,\n'
printf '301-flags/phonons.facet and 302-flags/phonons.facet under Results.\n'
printf 'Check static vector controls, batch switching, phonon units and animation.\n'
if [ "$install" -eq 1 ]; then
  printf '\n[6] Configure Bash PATH for this package directory\n'
  bash "$package_dir/install.sh"
else
  printf '\nPATH unchanged (--no-install).\n'
fi
