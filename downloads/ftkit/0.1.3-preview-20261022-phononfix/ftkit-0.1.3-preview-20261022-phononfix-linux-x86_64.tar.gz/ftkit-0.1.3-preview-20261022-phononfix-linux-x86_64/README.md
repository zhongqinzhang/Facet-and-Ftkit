# Ftkit 0.1.3 Linux 测试包

配套 **支持当前原生格式的 Facet 0.1.1 Alpha 开发/修复版**。当前共享层声子 schema 为 5，较早的同版本号安装包可能需要更新；软件改名本身不修改格式。本版含 101、103、201、202、301、302 六个任务。

**2026-10-22 声子兼容修复**：301 正确读取 VASP 质量修正段的双行标题，不再误报重复段或缺少全部模式；模式表后的晶胞与有效 POMASS 仍继续校验，冲突时停止转换并保留旧输出。已用 VASP 6.5.1 的 28 原子 OUTCAR 转换并回读全部 84 个模式（含 3 个虚频）。无需新增参数，原始输入不改写。

**2026-10-16 相对能量更新**：101 / 103 的每个输出文件以本次轨迹 / NEB 路径的最低最终 TOTEN 为零点，单位仍为 eV；NEB 包含端点，缺失能量保持缺失。例如 `[-10, -12, -11]` 写成 `[2, 0, 1]`。默认生效，无需新参数。源文件不改写，已有 `.facet` 需重新转换才采用新零点。

**2026-09-28 声子修复包（phononfix）**：删除 301 按原子数估算的 256 MiB 拒绝阈值，并同步取消共享读写层对声子模式块的独立 64 MiB 上限。555 原子 / 1665 个密集模式已能转换及回读，超过 128 MiB 的模式块已通过项目保存与重开。文件格式与科学数值不变；其他类型的单块限制及整包 2 GiB、总展开 4 GiB 等检查保留。应配套同日 Facet 声子修复版，旧查看器仍可能拒绝大文件。验证记录见 BUILDINFO.json；Linux 实机仍待验证。

## 目录

1. [安装](#安装)
2. [手册与更新](#手册与更新)
3. [验收与限制](#验收与限制)

## 安装

本次包名为 `ftkit-0.1.3-preview-20261022-phononfix-linux-x86_64.tar.gz`，版本仍为 0.1.3。只提供 `ftkit` 命令；安装器迁移旧版管理的 Bash PATH 区块，用户脚本中的旧命令需要手动更新。本包含此次 301 修复及此前全部功能，101/103 仍显示 `Relative energy (eV)`。共享数据层沿用 20261016-r2 包的来源，声子 schema 仍为 5；菜单、参数与文件格式不变。

在解压目录执行：

```bash
bash verify.sh
source "$HOME/.config/ftkit/env.sh"
ftkit --version
```

验证通过后已把解压目录配置到 Bash PATH，新终端自动生效。当前终端需执行一次 source。只验证用 `bash verify.sh --no-install`，已有验证结果时可用 `bash install.sh` 单独安装。请长期保留解压目录。

## 手册与更新

包内 `docs/zh-CN/用户手册.txt` 和 `docs/zh-CN/更新说明.txt` 可用文本编辑器阅读；也可在 Linux 执行：

```bash
less docs/zh-CN/用户手册.txt
```

磁矩默认长度缩至前一个公共尺寸基准的 85%，202 整个项目共用比例。配套 Facet 的声子默认长度缩至 50%。粗度与各自颜色保留，已有文件保存的外观优先。菜单保留边框，去掉冗余宣传句；摘要不显示 Elapsed/Next。输出默认覆盖，不询问。

例子：

```bash
cd example/magnetic
../../ftkit -task 201
```

`example/OUTCAR` 是 VASP 声子输入；`example/qe/` 是 QE 三文件输入；`example/soc/` 是非共线/SOC 输入。完整命令见手册。

## 验收与限制

校验文件为 SHA256SUMS；BUILDINFO.json 记录版本、构建工具链、ELF 审计、验证范围，BUILD-SOURCES.sha256 记录编译输入指纹。THIRD-PARTY-NOTICES.md 与 licenses/ 保留依赖许可。

本机通过 49 项 Ftkit 测试，另单独通过用户真实 OUTCAR 的原生回读测试；555 原子 / 1665 模式大样例继续通过。Linux 静态构建与 ELF 审计结果见 BUILDINFO.json。仓库级 pnpm check / pnpm build 最终均通过；未修改无关 Facet 文件。

Linux 新版实机验证尚未完成，尤其 CentOS 6.7 / 内核 2.6.32。请在三台目标机分别运行 verify.sh 并保留报告。101 的 stride 和 101/103 的统一中断/发布流程仍待完善，完整限制见手册。
